import { VaultCryptoError } from './errors.ts';
import { assessPassword, createKdfParams, deriveKek, type KdfParams } from './kdf.ts';
import { decryptBytes, encryptBytes, type Envelope } from './aes.ts';
import { randomBytes } from './random.ts';
import { wipe } from './bytes.ts';
import { subtle } from './subtle.ts';

/**
 * Key hierarchy
 * -------------
 *   Master Password
 *        ↓  PBKDF2-SHA256, >= 600k iterations, per-vault salt
 *   Key Encryption Key (KEK, non-extractable)
 *        ↓  AES-GCM wrap, AAD "pv.dek.v1"
 *   Wrapped Data Encryption Key   ← the only thing persisted
 *        ↓  unwrap on unlock
 *   Data Encryption Key (DEK, non-extractable)
 *        ↓  AES-GCM per record, AAD binds record identity
 *   Item / index / file ciphertext
 *
 * Because data is encrypted under an independent DEK, changing the master
 * password only rewraps 32 bytes: no user data is re-encrypted, and no data
 * can be lost by a password change.
 */

export const DEK_AAD = 'pv.dek.v1';
export const DEK_BYTES = 32;

export interface Keyring {
  readonly version: 1;
  readonly kdf: KdfParams;
  readonly wrappedDek: Envelope;
}

export interface CreatedKeyring {
  readonly keyring: Keyring;
  readonly dek: CryptoKey;
}

async function importDek(raw: Uint8Array): Promise<CryptoKey> {
  // extractable: false — after this point the raw DEK bytes are not reachable
  // from JavaScript, only usable through crypto.subtle.
  return subtle().importKey('raw', raw, { name: 'AES-GCM', length: 256 }, false, [
    'encrypt',
    'decrypt',
  ]);
}

export async function createKeyring(password: string, iterations?: number): Promise<CreatedKeyring> {
  if (!assessPassword(password).acceptable) throw new VaultCryptoError('WEAK_PASSWORD');
  const kdf = createKdfParams(iterations);
  const kek = await deriveKek(password, kdf);
  const rawDek = randomBytes(DEK_BYTES);
  try {
    const wrappedDek = await encryptBytes(kek, rawDek, DEK_AAD);
    const dek = await importDek(rawDek);
    return { keyring: { version: 1, kdf, wrappedDek }, dek };
  } finally {
    wipe(rawDek);
  }
}

/**
 * Unlock. A failed GCM tag here means the password is wrong OR the stored
 * keyring was modified; both are reported as WRONG_PASSWORD to the user
 * because we cannot distinguish them and the recovery action is the same.
 */
export async function unlockKeyring(password: string, keyring: Keyring): Promise<CryptoKey> {
  if (keyring?.version !== 1) throw new VaultCryptoError('UNSUPPORTED_KDF');
  const kek = await deriveKek(password, keyring.kdf);
  let rawDek: Uint8Array | undefined;
  try {
    rawDek = await decryptBytes(kek, keyring.wrappedDek, DEK_AAD);
    return await importDek(rawDek);
  } catch {
    throw new VaultCryptoError('WRONG_PASSWORD');
  } finally {
    wipe(rawDek);
  }
}

/**
 * Rewraps the existing DEK under a key derived from the new password.
 * The caller must persist the returned keyring atomically; until it does, the
 * old keyring stays valid, so an interrupted password change cannot lock the
 * user out of their data.
 */
export async function changePassword(
  currentPassword: string,
  newPassword: string,
  keyring: Keyring,
  iterations?: number,
): Promise<Keyring> {
  if (!assessPassword(newPassword).acceptable) throw new VaultCryptoError('WEAK_PASSWORD');
  const oldKek = await deriveKek(currentPassword, keyring.kdf);
  let rawDek: Uint8Array | undefined;
  try {
    rawDek = await decryptBytes(oldKek, keyring.wrappedDek, DEK_AAD);
  } catch {
    throw new VaultCryptoError('WRONG_PASSWORD');
  }
  try {
    const kdf = createKdfParams(iterations);
    const newKek = await deriveKek(newPassword, kdf);
    const wrappedDek = await encryptBytes(newKek, rawDek, DEK_AAD);
    return { version: 1, kdf, wrappedDek };
  } finally {
    wipe(rawDek);
  }
}

/**
 * Wraps the vault DEK for an export bundle under a (possibly different)
 * backup password, so a backup is self-contained and never carries plaintext.
 */
export async function exportKeyringForBackup(
  vaultPassword: string,
  keyring: Keyring,
  backupPassword: string,
  iterations?: number,
): Promise<Keyring> {
  return changePassword(vaultPassword, backupPassword, keyring, iterations);
}
