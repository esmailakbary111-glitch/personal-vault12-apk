import { getAllFromIndex, requestToPromise, runTx } from './idb.ts';
import {
  META_KEY,
  STORE,
  type BlobChunkRecord,
  type ItemRecord,
  type SettingsRecord,
  type VaultMetaRecord,
} from './schema.ts';

/**
 * Storage layer. Knows records, keys and transactions.
 * Knows nothing about React, and never performs cryptography: callers hand it
 * finished envelopes so no transaction stays open across an await of crypto.
 */
export class VaultStore {
  constructor(private readonly db: IDBDatabase) {}

  close(): void {
    this.db.close();
  }

  // ---- meta -------------------------------------------------------------
  async readMeta(): Promise<VaultMetaRecord | undefined> {
    return runTx(this.db, [STORE.meta], 'readonly', (tx) =>
      requestToPromise<VaultMetaRecord | undefined>(
        tx.objectStore(STORE.meta).get(META_KEY) as IDBRequest<VaultMetaRecord | undefined>,
      ),
    );
  }

  async writeMeta(record: VaultMetaRecord): Promise<void> {
    await runTx(this.db, [STORE.meta], 'readwrite', (tx) => {
      tx.objectStore(STORE.meta).put(record);
    });
  }

  // ---- items ------------------------------------------------------------
  async listItemRecords(): Promise<ItemRecord[]> {
    return runTx(this.db, [STORE.items], 'readonly', (tx) =>
      requestToPromise<ItemRecord[]>(tx.objectStore(STORE.items).getAll() as IDBRequest<ItemRecord[]>),
    );
  }

  async getItemRecord(id: string): Promise<ItemRecord | undefined> {
    return runTx(this.db, [STORE.items], 'readonly', (tx) =>
      requestToPromise<ItemRecord | undefined>(
        tx.objectStore(STORE.items).get(id) as IDBRequest<ItemRecord | undefined>,
      ),
    );
  }

  async listTrashRecords(): Promise<ItemRecord[]> {
    return runTx(this.db, [STORE.items], 'readonly', (tx) =>
      getAllFromIndex<ItemRecord>(tx, STORE.items, 'by_deletedAt'),
    );
  }

  /** Single commit: the item and all of its file chunks land together. */
  async putItemWithBlobs(record: ItemRecord, chunks: BlobChunkRecord[]): Promise<void> {
    await runTx(this.db, [STORE.items, STORE.blobs], 'readwrite', (tx) => {
      tx.objectStore(STORE.items).put(record);
      const blobs = tx.objectStore(STORE.blobs);
      for (const chunk of chunks) blobs.put(chunk);
    });
  }

  async putItem(record: ItemRecord): Promise<void> {
    await runTx(this.db, [STORE.items], 'readwrite', (tx) => {
      tx.objectStore(STORE.items).put(record);
    });
  }

  /**
   * Chunk keys are resolved in a readonly transaction FIRST, then deleted in a
   * short write transaction. This avoids relying on a transaction staying
   * active across awaited requests, which is fragile across engines.
   */
  async deleteItemAndBlobs(id: string, blobIds: string[]): Promise<void> {
    const keys = await this.resolveBlobKeys(blobIds);
    await runTx(this.db, [STORE.items, STORE.blobs], 'readwrite', (tx) => {
      const blobs = tx.objectStore(STORE.blobs);
      for (const key of keys) blobs.delete(key);
      tx.objectStore(STORE.items).delete(id);
    });
  }

  private async resolveBlobKeys(blobIds: string[]): Promise<IDBValidKey[]> {
    if (blobIds.length === 0) return [];
    return runTx(this.db, [STORE.blobs], 'readonly', async (tx) => {
      const idx = tx.objectStore(STORE.blobs).index('by_blobId');
      const out: IDBValidKey[] = [];
      const results = await Promise.all(
        blobIds.map((blobId) => requestToPromise<IDBValidKey[]>(idx.getAllKeys(blobId))),
      );
      for (const keys of results) out.push(...keys);
      return out;
    });
  }

  async countItems(): Promise<number> {
    return runTx(this.db, [STORE.items], 'readonly', (tx) =>
      requestToPromise<number>(tx.objectStore(STORE.items).count()),
    );
  }

  // ---- blobs ------------------------------------------------------------
  async readBlobChunks(blobId: string): Promise<BlobChunkRecord[]> {
    const chunks = await runTx(this.db, [STORE.blobs], 'readonly', (tx) =>
      getAllFromIndex<BlobChunkRecord>(tx, STORE.blobs, 'by_blobId', blobId),
    );
    return chunks.sort((a, b) => a.chunk - b.chunk);
  }

  async writeBlobChunks(chunks: BlobChunkRecord[]): Promise<void> {
    await runTx(this.db, [STORE.blobs], 'readwrite', (tx) => {
      const store = tx.objectStore(STORE.blobs);
      for (const chunk of chunks) store.put(chunk);
    });
  }

  async listAllBlobChunks(): Promise<BlobChunkRecord[]> {
    return runTx(this.db, [STORE.blobs], 'readonly', (tx) =>
      requestToPromise<BlobChunkRecord[]>(
        tx.objectStore(STORE.blobs).getAll() as IDBRequest<BlobChunkRecord[]>,
      ),
    );
  }

  async deleteBlobs(blobIds: string[]): Promise<void> {
    const keys = await this.resolveBlobKeys(blobIds);
    if (keys.length === 0) return;
    await runTx(this.db, [STORE.blobs], 'readwrite', (tx) => {
      const store = tx.objectStore(STORE.blobs);
      for (const key of keys) store.delete(key);
    });
  }

  // ---- settings ---------------------------------------------------------
  async readSettings(): Promise<Record<string, unknown>> {
    const rows = await runTx(this.db, [STORE.settings], 'readonly', (tx) =>
      requestToPromise<SettingsRecord[]>(
        tx.objectStore(STORE.settings).getAll() as IDBRequest<SettingsRecord[]>,
      ),
    );
    return Object.fromEntries(rows.map((r) => [r.key, r.value]));
  }

  async writeSettings(entries: Record<string, unknown>): Promise<void> {
    await runTx(this.db, [STORE.settings], 'readwrite', (tx) => {
      const store = tx.objectStore(STORE.settings);
      for (const [key, value] of Object.entries(entries)) store.put({ key, value });
    });
  }

  // ---- restore (atomic swap) -------------------------------------------
  /**
   * Replaces vault contents in ONE transaction. Everything handed in has
   * already been decrypted, validated and re-encrypted by the caller, so this
   * commit is short and either fully applies or fully rolls back.
   */
  async replaceAll(payload: {
    meta: VaultMetaRecord;
    items: ItemRecord[];
    blobs: BlobChunkRecord[];
    settings?: Record<string, unknown>;
  }): Promise<void> {
    await runTx(
      this.db,
      [STORE.meta, STORE.items, STORE.blobs, STORE.settings, STORE.staging],
      'readwrite',
      (tx) => {
        tx.objectStore(STORE.items).clear();
        tx.objectStore(STORE.blobs).clear();
        tx.objectStore(STORE.staging).clear();
        tx.objectStore(STORE.meta).put(payload.meta);
        const items = tx.objectStore(STORE.items);
        for (const item of payload.items) items.put(item);
        const blobs = tx.objectStore(STORE.blobs);
        for (const chunk of payload.blobs) blobs.put(chunk);
        if (payload.settings) {
          const settings = tx.objectStore(STORE.settings);
          for (const [key, value] of Object.entries(payload.settings)) settings.put({ key, value });
        }
      },
    );
  }
}
