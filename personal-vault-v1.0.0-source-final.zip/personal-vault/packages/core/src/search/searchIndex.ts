import type { ItemSummary, ItemType } from '../domain/types.ts';

export type SortKey = 'updated_desc' | 'updated_asc' | 'created_desc' | 'title_asc' | 'type_asc';

export interface SearchQuery {
  readonly text?: string;
  readonly types?: ItemType[];
  readonly categories?: string[];
  readonly tags?: string[];
  readonly favoritesOnly?: boolean;
  readonly sort?: SortKey;
  readonly scope?: 'active' | 'trash';
}

interface IndexedDoc {
  readonly summary: ItemSummary;
  readonly haystack: string;
}

/**
 * In-memory search over the decrypted lightweight index.
 *
 * Persisting a plaintext search index would defeat the encryption, so the
 * index is rebuilt on unlock from the small per-item index envelopes and torn
 * down on lock. Matching is token-AND over a normalized haystack, which stays
 * linear and is fast into the tens of thousands of items.
 */
export class SearchIndex {
  private docs: IndexedDoc[] = [];

  static normalize(value: string): string {
    return value
      .toLowerCase()
      // Arabic/Persian orthography: unify letters users type interchangeably
      .replace(/[\u064A\u0649]/g, '\u06CC')
      .replace(/[\u0643]/g, '\u06A9')
      .replace(/[\u0623\u0625\u0622]/g, '\u0627')
      // strip Arabic diacritics and tatweel
      .replace(/[\u064B-\u0652\u0640]/g, '')
      // Persian/Arabic-Indic digits -> ASCII
      .replace(/[\u06F0-\u06F9]/g, (d) => String(d.charCodeAt(0) - 0x06f0))
      .replace(/[\u0660-\u0669]/g, (d) => String(d.charCodeAt(0) - 0x0660))
      .replace(/\u200c/g, ' ')
      .replace(/\s+/g, ' ')
      .trim();
  }

  rebuild(summaries: ItemSummary[]): void {
    this.docs = summaries.map((summary) => ({ summary, haystack: SearchIndex.buildHaystack(summary) }));
  }

  upsert(summary: ItemSummary): void {
    const doc = { summary, haystack: SearchIndex.buildHaystack(summary) };
    const at = this.docs.findIndex((d) => d.summary.id === summary.id);
    if (at >= 0) this.docs[at] = doc;
    else this.docs.push(doc);
  }

  remove(id: string): void {
    this.docs = this.docs.filter((d) => d.summary.id !== id);
  }

  clear(): void {
    this.docs = [];
  }

  get size(): number {
    return this.docs.length;
  }

  private static buildHaystack(summary: ItemSummary): string {
    return SearchIndex.normalize(
      [summary.title, summary.type, summary.category ?? '', summary.tags.join(' '), summary.preview].join('  '),
    );
  }

  search(query: SearchQuery = {}): ItemSummary[] {
    const scope = query.scope ?? 'active';
    const tokens = query.text ? SearchIndex.normalize(query.text).split(' ').filter(Boolean) : [];
    const types = query.types?.length ? new Set(query.types) : null;
    const categories = query.categories?.length ? new Set(query.categories) : null;
    const tags = query.tags?.length ? new Set(query.tags) : null;

    const results = this.docs
      .filter((doc) => {
        const s = doc.summary;
        if (scope === 'active' ? s.deletedAt !== null : s.deletedAt === null) return false;
        if (types && !types.has(s.type)) return false;
        if (categories && !(s.category && categories.has(s.category))) return false;
        if (tags && !s.tags.some((t) => tags.has(t))) return false;
        if (query.favoritesOnly && !s.favorite) return false;
        return tokens.every((token) => doc.haystack.includes(token));
      })
      .map((doc) => doc.summary);

    return SearchIndex.sort(results, query.sort ?? 'updated_desc');
  }

  static sort(items: ItemSummary[], sort: SortKey): ItemSummary[] {
    const copy = [...items];
    switch (sort) {
      case 'updated_asc':
        return copy.sort((a, b) => a.updatedAt - b.updatedAt);
      case 'created_desc':
        return copy.sort((a, b) => b.createdAt - a.createdAt);
      case 'title_asc':
        return copy.sort((a, b) => a.title.localeCompare(b.title, 'fa'));
      case 'type_asc':
        return copy.sort((a, b) => a.type.localeCompare(b.type) || b.updatedAt - a.updatedAt);
      case 'updated_desc':
      default:
        return copy.sort((a, b) => b.updatedAt - a.updatedAt);
    }
  }

  facets(): { types: Record<string, number>; categories: Record<string, number>; tags: Record<string, number> } {
    const types: Record<string, number> = {};
    const categories: Record<string, number> = {};
    const tags: Record<string, number> = {};
    for (const { summary } of this.docs) {
      if (summary.deletedAt !== null) continue;
      types[summary.type] = (types[summary.type] ?? 0) + 1;
      if (summary.category) categories[summary.category] = (categories[summary.category] ?? 0) + 1;
      for (const tag of summary.tags) tags[tag] = (tags[tag] ?? 0) + 1;
    }
    return { types, categories, tags };
  }
}
