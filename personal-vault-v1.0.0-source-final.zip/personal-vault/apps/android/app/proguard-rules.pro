# Personal Vault v1 does not minify release builds yet. Keep this file for reviewed rules.
