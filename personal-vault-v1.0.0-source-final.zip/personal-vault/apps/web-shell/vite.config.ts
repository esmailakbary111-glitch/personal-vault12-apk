import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import { fileURLToPath, URL } from 'node:url';

export default defineConfig({
  plugins: [react()],
  resolve: {
    alias: {
      '@pv/core': fileURLToPath(new URL('../../packages/core/src', import.meta.url)),
      '@pv/crypto': fileURLToPath(new URL('../../packages/crypto/src', import.meta.url)),
      '@pv/ui': fileURLToPath(new URL('../../packages/ui/src', import.meta.url)),
    },
  },
  build: {
    sourcemap: false,
  },
});
